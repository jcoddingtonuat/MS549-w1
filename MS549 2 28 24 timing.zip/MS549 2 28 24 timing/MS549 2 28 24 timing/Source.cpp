#include <iostream>
#include <string>
#include <time.h>
#include <Windows.h>

using namespace std;

int main()
{
	clock_t start, end;

	start = clock();// notes the time
	Sleep(2000);// example
	end = clock(); // notes the end time
	cout << "time elapsed: " << (end - start) << " in MS" << endl;
	system("pause");
	return 0;
} 