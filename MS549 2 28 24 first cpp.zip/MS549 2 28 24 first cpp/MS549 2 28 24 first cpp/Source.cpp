// this is a comment
/* this is 
    a 
    multi line 
    comment
    
    */


//
#include <iostream>
#include <string>
using namespace std;

int main()
{

    //declare variables
    int number = 3;
    bool notDone = true;
    int guess = 0;
    while (notDone)
    {
        cout << "please enter a guess 1-5" << endl;
        cin >> guess;

   /*     if (guess < number)
        {
            cout << "too low" << endl;
        }
        else if (guess > number)
        {
            cout << "too high" << endl;
        }
        else
        {
            cout << "You guessed it" << endl;
            notDone = false;
        }
*/

        switch (guess)
        {
            case 1:
                cout << "1 is too low" << endl;
                break;
            case 2:
                cout << "2 is too low" << endl;
                break;
            case 3:
                cout << "correct" << endl;
                notDone = false;
                break;
            case 4:

                cout << "4 is too high" << endl;
                break;
            case 5:
                cout << "5 is too high" << endl;
                break;
            default:
                cout << "invalid # as guess" << endl;
        } // end switch


     
    }
    return 0;
}