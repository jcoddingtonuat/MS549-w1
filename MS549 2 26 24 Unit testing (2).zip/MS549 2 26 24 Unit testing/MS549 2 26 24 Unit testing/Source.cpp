#define NDEBUG // turn off all assert commands - no need to delete  *** needs to be at the top!

#include <iostream>
#include <string>
#include <cassert>

using namespace std;

string greeting(string name)
{
	return "Hello " + name + "!";
}



int main()
{

	// test 1
	assert(greeting("Jill") == "Hello Jill!");
	assert(greeting("hank") == "Hello hank?");

	cout << "end of program" << endl;
	return 0;
}